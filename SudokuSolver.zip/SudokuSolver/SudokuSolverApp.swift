//
//  SudokuSolverApp.swift
//  SudokuSolver
//
//  Created by Sebastian Castro on 5/21/23.
//

import SwiftUI

@main
struct SudokuSolverApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
